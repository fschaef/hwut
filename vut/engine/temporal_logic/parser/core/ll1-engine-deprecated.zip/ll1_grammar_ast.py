"""SPDX-License: MIT; Project VUT; (C) Frank-Rene Schaefer
______________________________________________________________________________

GRAMMAR NODES  --  the compiled grammar as a uniform polymorphic tree.

Compiling a rule turns its authored structure (see grammar.py / combinators.py)
into a tree of Node objects. EVERY element is a Node, so the engine never
switches on a kind: it calls a method and the node does the right thing.

NODE HIERARCHY:

    Node
     |
     +-- TerminalNode        a leaf that consumes ONE token. A plain terminal
     |                       (regex / captured / silent keyword) appends its
     |                       Token; an OPAQUE (Luau) terminal drives the oracle
     |                       and appends a Luau span. A terminal is never subject
     |                       to construction branching, so an opaque (Luau)
     |                       span is just the 'opaque' flavour of terminal.
     |
     +-- PassThroughNode      a resolved rule reference. It owns no parse
     |                       decision: it opens a frame, runs the rule's reduce
     |                       action, and forwards the single value of an
     |                       action-less rule. The name says "passes through".
     |
     +-- BranchNode           the multi-child combinators -- an ordered list of
     |    |                  children. Shared base for the two whose structure is
     |    |                  "several sub-nodes".
     |    +-- SequenceNode     match each child in order.
     |    +-- AlternativeNode  match exactly one child by one-token lookahead
     |                        by one-token lookahead.
     |
     +-- OperatorNode         the single-body repetition/optionality combinators --
          |                  one 'body' sub-node, an arity policy on top. Shared
          |                  base for the three whose structure is "one body".
          +-- OptionalNode     body zero or one time.
          +-- StarNode         body zero or more times.
          +-- PlusNode         body one or more times.

Each Node implements the operations the parser-preparation and the parse itself
need:

    first_set(grammar) -> set[Terminal]   terminals that can begin this node
    nullable(grammar)  -> bool             can this node match no tokens
    children()         -> iterable[Node]   the immediate sub-nodes (for generic
                                           tree walks; leaves yield none)
    expand(parser, frames, work)           one step of the iterative parse:
                                           push work / consume input / append a
                                           value to the current frame

LL(1) conflict detection (check_alts) is NOT a per-node recursive method any
more: a deep grammar would recurse as deep as it nests and could overflow the
C stack. It is an external worklist walk -- see collect_alt_conflicts() -- that
descends the tree with an explicit stack. Each AlternativeNode contributes the
"a token starts two branches" test; every other node just exposes children().

'grammar' is passed in (a duck-typed object exposing the name->PassThroughNode
map as '.rules'); nodes hold no engine state, so this module depends only on the
terminals layer -- never on the engine.

The parse is driven by an explicit work stack (ll1_engine._match), not by
recursion, so 'expand' pushes follow-up work rather than calling itself. The
work-instruction tags ELEM / REDUCE / LOOP are defined here and shared with the
engine.
______________________________________________________________________________
"""
from .terminals import t_fr_luau_open


# Work-instruction tags for the parser's explicit stack (see ll1_engine).
#   (ELEM,  node)            expand 'node'
#   (REDUCE, nt)             finish PassThroughNode 'nt': pop frame, act, append
#   (LOOP,  body)            a PLUS/STAR iteration point
ELEM   = 0
REDUCE = 1
LOOP   = 2


class Node:
    """Abstract base for every compiled grammar element.

    The interface below is the whole contract the engine and the analysis use;
    no engine code inspects a node's concrete type. 'children' lets a generic
    walk (the LL(1) conflict collector) descend without knowing the subclass.
    """
    __slots__ = ()

    def first_set(self, grammar):
        """RETURN: set[Terminal], the terminals that can begin this node."""
        raise NotImplementedError

    def nullable(self, grammar):
        """RETURN: True,  if this node can match the empty token sequence;
                   False, else.
        """
        raise NotImplementedError

    def children(self):
        """RETURN: iterable[Node], the immediate sub-nodes of this node.

        A leaf yields nothing; a BranchNode yields its branches; an OperatorNode
        yields its single body. A PassThroughNode yields NOTHING here: a
        reference does NOT re-descend into the referenced rule (each rule's own
        pattern is walked once by the analysis driver), so following it would
        loop on a recursive grammar.
        """
        return ()

    def expand(self, parser, frames, work):
        """RETURN: None. Performs one parse step for this node against the
                parser's token stream, mutating 'frames' and 'work' in place.

        A leaf consumes input and may append a value to frames[-1]; a combinator
        pushes follow-up (ELEM/REDUCE/LOOP) work. Raises _ResyncError (from the
        engine) on a token mismatch.
        """
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Leaves.
# ---------------------------------------------------------------------------
class TerminalNode(Node):
    """A leaf consuming one token; a plain terminal OR an opaque Luau span.

    A terminal is never subject to construction branching, so the opaque Luau
    span is just an opaque flavour of terminal here,
    discriminated by the carried Terminal's shape ('opaque'):

      - plain (regex / captured / silent string): matches the token by identity.
        'silent' True drops it (punctuation: keywords, symbols); False keeps the
        Token (ID, NUMBER, STRING, captured keywords).
      - opaque: matches a '{' and drives the oracle to read the whole '{ ... }'
        span under the terminal's Role; always value-bearing (a Luau node),
        never silent.

    FIRST is the carried terminal for a plain leaf, and the Luau-open framing
    token for an opaque leaf.
    """
    __slots__ = ("token_id", "silent")

    def __init__(self, token_id, silent):
        self.token_id = token_id
        self.silent   = silent

    @property
    def is_opaque(self):
        """RETURN: True, if this leaf is an opaque Luau span; else False."""
        return self.token_id.shape == "opaque"

    def __repr__(self):
        if self.is_opaque:
            return "T(luau:%s)" % self.token_id.role.name
        return "T(%s%s)" % (self.token_id._name(), "" if self.silent else "*")

    def first_set(self, grammar):
        if self.is_opaque:
            return {t_fr_luau_open}
        return {self.token_id}

    def nullable(self, grammar):
        return False

    def expand(self, parser, frames, work):
        if self.is_opaque:
            frames[-1].values.append(parser.consume_luau(self))
        else:
            value = parser.consume_terminal(self)
            if value is not None:
                frames[-1].values.append(value)


class PassThroughNode(Node):
    """A resolved rule reference: its name, compiled pattern, action, FIRST set.

    It owns no parse decision -- it opens a frame,
    schedules the reduce, and lets the pattern run; on reduce it runs the rule's
    action (or, action-less, forwards its single child value). A reference and
    its definition are the SAME object -- the engine interns one PassThroughNode
    per rule name -- so a reference sees the definition's pattern and FIRST
    automatically.
    """
    __slots__ = ("name", "action", "pattern", "first")

    def __init__(self, name, action):
        self.name    = name
        self.action  = action
        self.pattern = None        # set during compile
        self.first   = set()       # filled during analysis

    def __repr__(self):
        return "PT(%s)" % self.name

    def first_set(self, grammar):
        return set(self.first)

    def nullable(self, grammar):
        # The rule-file grammar has no nullable non-terminals; treat as False
        # (kept exact for this grammar, as the previous engine did).
        return False

    # children() inherits the empty default ON PURPOSE: a reference does not
    # re-descend into the referenced rule -- following it would loop forever on
    # a recursive grammar, and each rule's pattern is walked once by the driver.

    def expand(self, parser, frames, work):
        # Open a fresh frame, schedule the reduce, then expand the pattern
        # (pushed last so it runs first).
        parser.open_frame(frames)
        work.append((REDUCE, self))
        work.append((ELEM, self.pattern))


# ---------------------------------------------------------------------------
# Combinators: BranchNode (several children) and OperatorNode (one body).
# ---------------------------------------------------------------------------
class BranchNode(Node):
    """Shared base for the multi-child combinators (Sequence / Alternative).

    Holds an ordered tuple of sub-nodes in 'branches'. The two derivatives
    differ in HOW the children combine (all-in-order vs choose-one), captured by
    first_set / nullable / expand; the children themselves are uniform here.
    """
    __slots__ = ("branches",)

    def __init__(self, branches):
        self.branches = tuple(branches)

    def children(self):
        return self.branches


class SequenceNode(BranchNode):
    """A sequence: match each child in order."""
    __slots__ = ()

    def __repr__(self):
        return "Seq(%s)" % ", ".join(map(repr, self.branches))

    def first_set(self, grammar):
        result = set()
        for sub in self.branches:
            result |= sub.first_set(grammar)
            if not sub.nullable(grammar):
                break
        return result

    def nullable(self, grammar):
        return all(sub.nullable(grammar) for sub in self.branches)

    def expand(self, parser, frames, work):
        for sub in reversed(self.branches):
            work.append((ELEM, sub))


class AlternativeNode(BranchNode):
    """An alternation: match exactly one branch by one-token lookahead.

    The LL(1) requirement (the branches' FIRST sets are
    pairwise disjoint) is what makes the single-token choice unambiguous; it is
    validated by collect_alt_conflicts(), not by this node.
    """
    __slots__ = ()

    def __repr__(self):
        return "Alt(%s)" % " | ".join(map(repr, self.branches))

    def first_set(self, grammar):
        result = set()
        for sub in self.branches:
            result |= sub.first_set(grammar)
        return result

    def nullable(self, grammar):
        return any(sub.nullable(grammar) for sub in self.branches)

    def expand(self, parser, frames, work):
        work.append((ELEM, parser.choose_alt(self)))


class OperatorNode(Node):
    """Shared base for the single-body combinators (Optional / Star / Plus).

    Holds one sub-node in 'body' and applies a repetition/optionality policy on
    top of it. The derivatives differ only in their lower bound (0 or 1) and
    whether the body repeats; FIRST is always the body's FIRST.
    """
    __slots__ = ("body",)

    def __init__(self, body):
        self.body = body

    def children(self):
        return (self.body,)

    def first_set(self, grammar):
        return self.body.first_set(grammar)


class OptionalNode(OperatorNode):
    """An option: match the body zero or one time."""
    __slots__ = ()

    def __repr__(self):
        return "Opt(%r)" % (self.body,)

    def nullable(self, grammar):
        return True

    def expand(self, parser, frames, work):
        if parser.starts(self.body):
            work.append((ELEM, self.body))


class StarNode(OperatorNode):
    """A repetition: match the body zero or more times."""
    __slots__ = ()

    def __repr__(self):
        return "Star(%r)" % (self.body,)

    def nullable(self, grammar):
        return True

    def expand(self, parser, frames, work):
        work.append((LOOP, self.body))


class PlusNode(OperatorNode):
    """A repetition: match the body one or more times."""
    __slots__ = ()

    def __repr__(self):
        return "Plus(%r)" % (self.body,)

    def nullable(self, grammar):
        return False

    def expand(self, parser, frames, work):
        # One mandatory body, then a loop for the rest.
        work.append((LOOP, self.body))
        work.append((ELEM, self.body))


# ---------------------------------------------------------------------------
# LL(1) conflict detection -- external worklist walk, NOT node recursion.
# ---------------------------------------------------------------------------
def _first_sets_iterative(pattern, grammar):
    """RETURN: dict, node -> its FIRST set, for every node beneath 'pattern'.

    Computes FIRST iteratively (post-order over children()), so a deeply nested
    inline combinator tree cannot overflow the C stack the way the recursive
    per-node first_set would. A PassThroughNode is a LEAF here -- its FIRST is
    the rule's already-memoised 'first' set (filled by the engine's fixpoint), so
    the walk never descends into another rule and a recursive grammar stays
    finite. Sequence FIRST honours nullable prefixes; everything else unions its
    children.
    """
    # 1. gather nodes in an order where a node appears AFTER its children.
    order = []
    work  = [pattern]
    while work:
        node = work.pop()
        order.append(node)
        if not isinstance(node, PassThroughNode):
            work.extend(node.children())
    # 2. fold FIRST up the tree (reverse order = children before parents).
    first = {}
    null  = {}
    for node in reversed(order):
        if isinstance(node, TerminalNode):
            first[node] = node.first_set(grammar)
            null[node]  = False
        elif isinstance(node, PassThroughNode):
            first[node] = set(node.first)        # memoised; not re-descended
            null[node]  = node.nullable(grammar)
        elif isinstance(node, SequenceNode):
            acc = set()
            nullable_prefix = True
            for sub in node.branches:
                if nullable_prefix:
                    acc |= first[sub]
                    nullable_prefix = null[sub]
            first[node] = acc
            null[node]  = all(null[s] for s in node.branches)
        elif isinstance(node, AlternativeNode):
            first[node] = set().union(*(first[s] for s in node.branches)) \
                          if node.branches else set()
            null[node]  = any(null[s] for s in node.branches)
        else:  # OperatorNode (Optional / Star / Plus)
            first[node] = first[node.body]
            null[node]  = isinstance(node, (OptionalNode, StarNode))
    return first


def collect_alt_conflicts(pattern, rule_name, grammar):
    """RETURN: list[str], every LL(1) ALT conflict beneath 'pattern'.

    Walks the compiled 'pattern' tree of one rule with EXPLICIT stacks -- both
    the descent (children()) and the FIRST-set computation are iterative -- so a
    deeply nested grammar cannot overflow the C stack at any point. At each
    AlternativeNode a token appearing in more than one branch's FIRST set is
    reported. A PassThroughNode yields no children, so the walk never follows a
    reference into another rule (which would loop on a recursive grammar); each
    rule is walked once by the caller.
    """
    first = _first_sets_iterative(pattern, grammar)
    conflicts = []
    work = [pattern]
    while work:
        node = work.pop()
        if isinstance(node, AlternativeNode):
            seen = {}
            for branch in node.branches:
                for tid in first[branch]:
                    if tid in seen:
                        conflicts.append(
                            "rule %s: token %s starts two ALT branches"
                            % (rule_name, tid._name()))
                    else:
                        seen[tid] = branch
        if not isinstance(node, PassThroughNode):
            work.extend(node.children())
    return conflicts
