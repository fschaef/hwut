from hwut.engine.quex.typed import typed

from collections import namedtuple

class ConsistentAnalogyList(list):
    def __init__(self, analogy_db):
        list.__init__(self, (
            (subject_term, entry.nominal_term)
            for subject_term, entry in analogy_db.items()
        ))

    @staticmethod
    def from_list(analogy_list):
        result = ConsistentAnalogyList({})
        result.extend(analogy_list)
        return result

ConsistentAnalogyList_Empty = ConsistentAnalogyList({})

AnalogyDbEntry = namedtuple("AnalogyDbEntry", ("nominal_term", "ia", "ib"))

class AnalogyDb(dict):
    """map: subject term --> (nominal term, ia, ib)

    where 'ia' and 'ib' give the indices of the lines in subject and
    nominal which imposed the analogy (subject term=nominal term).
    """
    def __init__(self, other=None):
        if other is not None: self.update(other)

    @staticmethod
    def from_dict(dictionary):
        result = AnalogyDb()
        result.update(
            (subject_term, AnalogyDbEntry(nominal_term, -1, -1))
            for subject_term, nominal_term in dictionary.items()
        )
        return result

    def clone(self):
        return AnalogyDb(self)

    def update_if_consistent(self, ia, ib, analogy_list):
        if not self.is_consistent(analogy_list):
            return False
        else:
            self.__update(ia, ib, analogy_list)
            return True

    def add(self, analogy):
        subject, nominal = analogy
        self[subject] = nominal

    def is_consistent(self, analogy):
        """RETURNS: True, if analogy = tuple(subject, nominal) is consistent
                          with all entries in database; False, else.
        """
        if analogy is None: return True
        else:               return self.__consistent(*analogy)

    def __update(self, ia, ib, analogy_list):
        self.update(
            (subject_term, AnalogyDbEntry(nominal_term, ia, ib))
            for subject_term, nominal_term in analogy_list
        )

    def __consistent(self, subject, nominal):
        """RETURNS: True, if association 'subject' vs. 'nominal' is consistent
                          with database.
                    False, else.
        """
        entry = self.get(subject)
        if entry is not None:
            return entry.nominal_term == nominal
        elif any(nominal == entry.nominal_term for entry in self.values()):
            return False
        else:
            return True

    def __repr__(self):
        return "[" + ", ".join('"%s":"%s"' % (one, other.nominal_term)
                               for one, other in sorted(self.items())) + "]"

