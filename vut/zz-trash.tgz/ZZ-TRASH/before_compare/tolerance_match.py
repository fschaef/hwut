from   hwut.engine.quex.typed import typed

from   enum        import Enum, IntEnum, auto
from   itertools   import zip_longest
from   collections import namedtuple

class E_ToleranceId(IntEnum):
    # IntEnum => facilitate comparison/sorting based on E_ToleranceId
    STRING          = 1
    ANALOGY         = 2
    WHITESPACE      = 3
    BACKSLASH       = 4
    NUMBER          = 5
    PATTERN         = 6
    VISIBLE_NOTHING = 7


class Match:
    def __init__(self, tolerance_id, start, end, string, pattern_index_set=None):
        assert isinstance(tolerance_id, E_ToleranceId)
        self.tolerance_id      = tolerance_id
        self.start             = start
        self.end               = end
        self.reference         = string
        self.pattern_index_set = pattern_index_set

    @staticmethod
    def from_tail(match_list):
        """RETURNS: Match object containing that concatenates all strings
                    from match_list[i] to the end of the list.
        """
        if match_list:
            start, end = match_list[0].start, match_list[-1].end
            reference  = match_list[0].reference
        else:
            start, end = 0, 0
            reference  = ""
        return Match(E_ToleranceId.STRING, start, end, reference)

    @property
    def string(self):
        return self.reference[self.start:self.end]

    def __hash__(self):
        if self.tolerance_id == E_ToleranceId.STRING:
            return hash(self.string) ^ hash(self.tolerance_id)
        else:
            return hash(self.tolerance_id)

    def __repr__(self):
        if self.tolerance_id != E_ToleranceId.PATTERN:
            return "(%i,%i): %s '%s';" % (self.start, self.end, self.tolerance_id.name, self.string)
        else:
            return "(%i,%i): %s %s '%s';" % (self.start, self.end, self.tolerance_id.name,
                                             list(sorted(self.pattern_index_set)), self.string)


class MatchLine(tuple):
    @typed(match_line=tuple, line_n=(int, None))
    def __new__(self, match_line, line_n=None):
        result = tuple.__new__(MatchLine, match_line)
        result.line_n = line_n
        return result


class E_Verdict(Enum):
    SUCCESS            = auto()
    FAILURE            = auto()
    SUBJECT_EXHAUSTED  = auto()  # no more subject data, nominal still present
    NOMINAL_EXHAUSTED  = auto()  # no more nominal data, subject still present

    MISFIT             = auto()  # tolerance patterns differed
    SUBJECT_PLUG       = auto()  # additional subject pattern appeared
    NOMINAL_PLUG       = auto()  # additional nominal pattern appeared

    @staticmethod
    def from_bool(verdict):
        if verdict: return E_Verdict.SUCCESS
        else:       return E_Verdict.FAILURE


class CmpInfo:
    @typed(verdict_id=E_Verdict)
    def __init__(self, verdict_id):
        self.verdict_id = verdict_id

class CmpInfoMatch(CmpInfo):
    @typed(verdict_id=E_Verdict, subject=(None, Match), nominal=(None, Match))
    def __init__(self, verdict_id, subject, nominal):
        CmpInfo.__init__(self, verdict_id)
        self.subject = subject
        self.nominal = nominal

    @staticmethod
    def SUCCESS(subject, nominal):
        return CmpInfoMatch(E_Verdict.SUCCESS, subject, nominal)

    @staticmethod
    def SUBJECT_PLUG(subject):
        return CmpInfoMatch(E_Verdict.SUBJECT_PLUG, subject, None)

    @staticmethod
    def NOMINAL_PLUG(nominal):
        return CmpInfoMatch(E_Verdict.NOMINAL_PLUG, None, nominal)

    def cost(self):
        cost_db = {
            E_Verdict.SUCCESS:            (0, 0),
            E_Verdict.SUBJECT_EXHAUSTED:  (4, 0),
            E_Verdict.NOMINAL_EXHAUSTED:  (4, 0),
            E_Verdict.SUBJECT_PLUG:       (0, 16),
            E_Verdict.NOMINAL_PLUG:       (0, 16),
            E_Verdict.MISFIT:             (1, 0),
            E_Verdict.FAILURE:            (0, 64)
        }
        if self.verdict_id == E_Verdict.SUBJECT_PLUG \
           and self.subject.tolerance_id == E_ToleranceId.WHITESPACE:
            return (0, 0)
        elif self.verdict_id == E_Verdict.NOMINAL_PLUG \
           and self.nominal.tolerance_id == E_ToleranceId.WHITESPACE:
            return (0, 0)
        elif self.verdict_id == E_Verdict.FAILURE \
           and self.nominal.tolerance_id == E_ToleranceId.STRING:
            return (0, edit_distance(self.subject.string, self.nominal.string))
        else:
            return cost_db[self.verdict_id]

    def __repr__(self):
        def _name(x):
            return "None" if x is None else "'%s'" % x.string
        if     self.subject is not None \
           and (self.verdict_id == E_Verdict.SUBJECT_PLUG or self.nominal is None):
            tolerance_id = self.subject.tolerance_id
        else:
            tolerance_id = self.nominal.tolerance_id
        return "%s(%s): s=%s; n=%s;" % (self.verdict_id.name, tolerance_id.name, \
                                        _name(self.subject), _name(self.nominal))

class CmpInfoLine(list):
    @typed(subject_line_n=(None, int), nominal_line_n=(None, int))
    def __init__(self, subject_line_n, nominal_line_n, cmp_info_iterable, verdict_id=None):
        list.__init__(self, cmp_info_iterable)

        self.subject_line_n = subject_line_n
        self.nominal_line_n = nominal_line_n

        if verdict_id is not None:
            self.verdict_id = verdict_id
        elif self.subject_line_n is None or self.nominal_line_n is None:
            self.verdict_id = E_Verdict.FAILURE
        else:
            self.verdict_id = E_Verdict.from_bool(all(ci.verdict_id == E_Verdict.SUCCESS for ci in self))

    @staticmethod
    def SUBJECT_PLUG(subject):
        cmp_info_list = (CmpInfoMatch.SUBJECT_PLUG(match) for match in subject)
        return CmpInfoLine(subject.line_n, None, cmp_info_list, E_Verdict.SUBJECT_PLUG)

    @staticmethod
    def NOMINAL_PLUG(nominal):
        cmp_info_list = (CmpInfoMatch.NOMINAL_PLUG(match) for match in nominal)
        return CmpInfoLine(None, nominal.line_n, cmp_info_list, E_Verdict.NOMINAL_PLUG)

    def cost(self):
        major, minor = 0, 0
        for verdict in self:
            cost = verdict.cost()
            major += cost[0]; minor += cost[1]
        return (major, minor)

    def __repr__(self):
        if self:
            cmp_info_list_str = ", ".join("%s" % v.verdict_id.name for v in self)
        else:
            cmp_info_list_str = "<no verdict>"
        if self.subject_line_n is None: sn = "--"
        else:                           sn = "%02i" % self.subject_line_n
        if self.nominal_line_n is None: nn = "--"
        else:                           nn = "%02i" % self.nominal_line_n
        return "[%s][%s] %s" % (sn, nn, cmp_info_list_str)

class CmpInfoPotpourri(list):
    @typed(verdict_id=E_Verdict)
    def __init__(self, cmp_info_line_iterable, verdict_id=None):
        list.__init__(self, cmp_info_line_iterable)
        if verdict_id is not None:
            self.verdict_id = verdict_id
        else:
            self.verdict_id = E_Verdict.from_bool(all(ci.verdict_id == E_Verdict.SUCCESS for ci in self))

    @staticmethod
    def SUBJECT_PLUG(cmp_info_line_iterable):
        cmp_info_line_iterable = (CmpInfoLine.NOMINAL_PLUG(line) for line in nominal)
        return CmpInfoPotpourri(cmp_info_line_iterable, E_Verdict.SUBJECT_PLUG)

    @staticmethod
    def NOMINAL_PLUG(nominal):
        cmp_info_line_iterable = (CmpInfoLine.NOMINAL_PLUG(line) for line in nominal)
        return CmpInfoPotpourri(cmp_info_line_iterable, E_Verdict.NOMINAL_PLUG)

    def cost(self):
        major, minor = 0, 0
        for cmp_info_line in self:
            cost = cmp_info_line.cost()
            major += cost[0]; minor += cost[1]
        return (major, minor)


class ComperatorMatch:
    """Comparison of two 'Match' objects.
    """
    def __init__(self, numeric_tolerance_ratio):
        self.__numeric_tolerance_ratio = numeric_tolerance_ratio

        self.compare_function_db = {
            E_ToleranceId.STRING:     self._compare_string,
            E_ToleranceId.ANALOGY:    self._compare_analogy,
            E_ToleranceId.WHITESPACE: self._compare_always_true,
            E_ToleranceId.BACKSLASH:  self._compare_always_true,
            E_ToleranceId.NUMBER:     self._compare_numbers,
            E_ToleranceId.PATTERN:    self._compare_pattern
        }

    def do(self, subject, nominal, analogy_db, ia=None, ib=None):
        """RETURNS: SUBJECT_EXHAUSTED
                    NOMINAL_EXHAUSTED
                    MISFIT
                    FAILURE
                    SUCCESS

        AFFECTS: 'analogy_db' if not None.
        """
        assert analogy_db is None or (ia is not None and ib is not None)
        assert subject is not None or nominal is not None

        if nominal.tolerance_id != subject.tolerance_id:
            return E_Verdict.MISFIT

        verdict, \
        analogy  = self.compare_function_db[nominal.tolerance_id](subject, nominal)

        if not verdict:
            return E_Verdict.FAILURE
        elif analogy_db is not None and not analogy_db.add_if_consistent(ia, ib, analogy):
            return E_Verdict.FAILURE
        else:
            return E_Verdict.SUCCESS

    def _compare_string(self, subject, nominal) -> bool:
        """RETURNS: [0] True, any way.
                    [1] Required analogy

        The judgement whether the subject and the nominal fit must be made
        by the analogy_db. The fact, that this function returns a second
        argument documents the need to do thie analogy check.
        """
        return subject.string == nominal.string, None

    def _compare_analogy(self, subject, nominal) -> bool:
        """RETURNS: [0] True, any way.
                    [1] Required analogy

        The judgement whether the subject and the nominal fit must be made
        by the analogy_db. The fact, that this function returns a second
        argument documents the need to do thie analogy check.
        """
        return True, (subject.string, nominal.string)

    def _compare_always_true(self, subject, nominal) -> bool:
        """RETURNS: [0] True, always.
                    [1] None (no analogy required)
        """
        return True, None

    def _compare_pattern(self, subject, nominal) -> bool:
        """RETURNS: [0] True, if subject and nominal match a common pattern.
                    [1] None (no analogy required)
        """
        return not subject.pattern_index_set.isdisjoint(nominal.pattern_index_set), None

    def _compare_numbers(self, subject, nominal) -> bool:
        """RETURNS: [0] True, if number 'subject' lies in the epsilon range
                              of number 'nominal'.
                        False, else.
                    [1] None (no analogy required)
        """
        subject_number = float(subject.string)
        nominal_number = float(nominal.string)
        epsilon        = abs(nominal_number * self.__numeric_tolerance_ratio)
        return abs(nominal_number - subject_number) <= epsilon, None


def edit_distance(a, b):
    """RETURNS: Measure of difference between string 'a' and string 'b'.

    This function implements a 'Levenshtein' based edit distance between
    two given strings. In order to tame the computational complexity of th
    underlying algorithm, the strings are separated into words. Words
    longer than 16 characters are pruned.
    """
    if a == b:
        return 0

    a_word_list = a.split() # Split string into words, to tame the levenshtein
    b_word_list = b.split() # complexity of O(M*N).

    result = 0
    for a_word, b_word in zip_longest(a_word_list, b_word_list):
        if   a_word is None:
            result += len(b_word)
        elif b_word is None:
            result += len(a_word)
        else:
            # consider only the first 16 letters
            # (reduce computational complexity)
            if   len(a_word) > 16: a_word = a_word[:16]
            elif len(b_word) > 16: b_word = b_word[:16]
            result += levenshtein(a_word, b_word)
    return result


def levenshtein(s, t):
    """This is an implementation of the Levenshtein Algorithm to determine the
    edit distance between two words 's' and 't'.

    Author:  Christopher P. Matthews;
             christophermatthews1985@gmail.com;
             Sacramento, CA, USA
    Source:  https://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Levenshtein_distance#Python
    License: (CC-BY-SA-3.0) Creative Commons
    """
    if s == t: return 0
    elif len(s) == 0: return len(t)
    elif len(t) == 0: return len(s)
    v0 = [None] * (len(t) + 1)
    v1 = [None] * (len(t) + 1)
    for i in range(len(v0)):
        v0[i] = i
    for i in range(len(s)):
        v1[0] = i + 1
        for j in range(len(t)):
            cost = 0 if s[i] == t[j] else 1
            v1[j + 1] = min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost)
        for j in range(len(v0)):
            v0[j] = v1[j]

    return v1[len(t)]
