from   hwut.engine.quex.typed              import typed
from   hwut.engine.tools                   import HwutIterator
from   hwut.engine.compare.analogy_db      import AnalogyDb
from   hwut.engine.compare.tolerance_match import E_ToleranceId,   \
                                                  E_Verdict,     \
                                                  Match,           \
                                                  MatchLine,       \
                                                  CmpInfoMatch,    \
                                                  ComperatorMatch, \
                                                  edit_distance

from   collections import namedtuple
from   itertools   import zip_longest, chain
from   functools   import lru_cache
import re

Tolerance = namedtuple("Tolerance", ("id", "pattern", "pattern_index"))

class ToleranceTable(list):
    def __init__(self, config):
        """Build the list of 'Tolerance' objects that are used to compare two lines.
        """
        def _add(tolerance_id, regex, pattern_index=None):
            if regex is not None: pattern = re.compile(regex)
            else:                 pattern = None
            self.append(Tolerance(tolerance_id, pattern, pattern_index))

        re_analogy    = r"\(\(" + r"([^\)]|[\)][^\)])+" + r"\)\)"
        re_whitespace = r"[ \t]+"
        re_backslash  = r"[\\/]+"
        re_number     = r"-?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?"

        _add(E_ToleranceId.STRING, None)

        if config.analogy_f:
            _add(E_ToleranceId.ANALOGY,    re_analogy)
            self.__analogy_pattern = self[1].pattern
        else:
            self.__analogy_pattern = None
        if config.whitespace_f:            _add(E_ToleranceId.WHITESPACE, re_whitespace)
        if config.backslash_f:             _add(E_ToleranceId.BACKSLASH,  re_backslash)
        if config.numeric_tolerance_ratio: _add(E_ToleranceId.NUMBER,     re_number)

        for pattern in config.visible_nothing_pattern_list:
            _add(E_ToleranceId.VISIBLE_NOTHING, pattern)

        for pattern_index, pattern in enumerate(config.equivalent_pattern_list):
            # If subject and nominal match the same pattern, then
            # this is sufficient to say 'equivalent'.
            _add(E_ToleranceId.PATTERN, pattern, pattern_index)

        self.comperator_match = ComperatorMatch(config.numeric_tolerance_ratio)

        self.strip_whitespace_f = config.strip_whitespace_f

    def create_MatchLine(self, string, line_n=None):
        def _analyze(string):
            if self.strip_whitespace_f:
                string = string.strip()

            i       = 0
            useless = set()
            while 1 + 1 == 2:
                tolerance_id, match_range, pattern_index_set = self._find_first_match(string, i, useless)
                if tolerance_id is None: break
                start, end = match_range
                if i != start:
                    yield Match(E_ToleranceId.STRING, i, start, string)
                if tolerance_id == E_ToleranceId.VISIBLE_NOTHING:
                    pass
                elif tolerance_id == E_ToleranceId.PATTERN:
                    yield Match(tolerance_id, start, end, string, pattern_index_set)
                else:
                    yield Match(tolerance_id, start, end, string)
                i = end

            if i != len(string):
                yield Match(E_ToleranceId.STRING, i, len(string), string)

        return MatchLine(tuple(_analyze(string)), line_n)


    def _find_first_match(self, string, i, useless):
        """RETURNS: [0] Index of first tolerance patterns that matched after
                              position in string 'i'.
                        Set of indices, if more than one user pattern matches
                              on the exact same span.
                    [1] Span if character indices where the pattern match.
        """
        class Best:
            def __init__(self):
                self.tolerance_id  = None
                self.span          = None
                self.pattern_i_set = None

            def set(self, tolerance, span):
                self.span         = span
                self.tolerance_id = tolerance.id
                if tolerance.id == E_ToleranceId.PATTERN:
                    self.pattern_i_set = set([tolerance.pattern_index])

            def add(self, tolerance):
                if self.tolerance_id == E_ToleranceId.PATTERN:
                    self.pattern_i_set.add(tolerance.pattern_index)
                else:
                    self.tolerance_id  = tolerance.id
                    self.pattern_i_set = set([tolerance.pattern_index])

        first = len(string)
        best  = Best()
        for index, tolerance in enumerate(self):
            if index in useless or tolerance.id == E_ToleranceId.STRING:
                continue
            m = tolerance.pattern.search(string, i)
            if not m:
                useless.add(index)
                continue
            elif not best.span or m.start() < best.span[0]:
                best.set(tolerance, m.span())
            elif best.span and m.start() == best.span[0]:
                if m.end() < best.span[1]:
                    continue
                elif m.end() > best.span[1]:
                    best.set(tolerance, m.span())
                elif tolerance.id == E_ToleranceId.PATTERN:
                    best.add(tolerance)

        return best.tolerance_id, best.span, best.pattern_i_set

class Processor(ToleranceTable):
    def __init__(self, config):
        ToleranceTable.__init__(self, config)

    @typed(subject_match_line=MatchLine, nominal_match_line=MatchLine)
    def judge(self, subject_match_line, nominal_match_line, analogy_db):
        """
        RETURNS: True, if subject and nominal are equivalent;
                 False, else.

        AFFECTS: 'analogy_db'
        """
        if len(subject_match_line) != len(nominal_match_line):
            return False

        ia = subject_match_line.line_n
        ib = nominal_match_line.line_n

        return all(self.comperator_match.do(s, n, analogy_db, ia, ib) == E_Verdict.SUCCESS
                   for s, n in zip(subject_match_line, nominal_match_line))

    def cmp_info_iterable(self, subject_match_line, nominal_match_line, analogy_db):

        cmp_info_list = list(self._cmp_info_iterable(subject_match_line, nominal_match_line, analogy_db))
        if all(ci.verdict_id == E_Verdict for ci in cmp_info_list):
            return cmp_info_list

        # Find relocations (A[i] == B[k] instead of A[i] == B[k])

    def _cmp_info_iterable(self, subject_match_line, nominal_match_line, analogy_db):
        """
        YIELDS: CmpInfoLine for each pair of elements in 'subject_match_line' and
                'nominal_match_line'.

        AFFECTS: 'analogy_db'
        """
        ia = subject_match_line.line_n
        ib = nominal_match_line.line_n

        subject_it = HwutIterator(subject_match_line)
        nominal_it = HwutIterator(nominal_match_line)
        for subject, nominal in zip_longest(subject_match_line, nominal_match_line):

            verdict_id = self.comperator_match.do(subject, nominal, analogy_db, ia, ib)

            if verdict_id == E_Verdict.SUBJECT_EXHAUSTED:
                nominal = Match.from_tail(chain([nominal], nominal_it.remaining()))
            elif verdict_id == E_Verdict.NOMINAL_EXHAUSTED:
                subject = Match.from_tail(chain([subject], subject_it.remaining()))
            yield CmpInfoMatch(verdict_id, subject, nominal)

