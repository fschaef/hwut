#! /usr/bin/env python3
#
# PURPOSE: 'main.py' -- driving the comparison of two streams
#
#
# SPDX-Linces: MIT; (C) Frank-Rene Schaefer.
#______________________________________________________________________________

import sys
import os
import re

sys.path.insert(0, "../../../../")

import hwut.engine.compare.comperator       as     comperator
import hwut.engine.compare.main             as     main
from   hwut.engine.tools                    import LineProviderFromArray

config = comperator.Configuration()
config.numeric_tolerance_ratio = 1.0
config.equivalent_pattern_list = [ "hallo" ]
config.whitespace_f = True

if "--hwut-info" in sys.argv:
    print("ComperatorLines;")
    print("CHOICES: lines, potpourri, chunk_pipe;")
    sys.exit()

def line_list_pair(text):
    first_list, second_list   = [], []
    first_end_f, second_end_f = False, False
    for line in text.splitlines():
        fields        = line.strip()[1:-1].split(":")
        if len(fields) != 2:
            continue
        first, second = fields

        if first.strip() == "<END>":  first_end_f = True
        if second.strip() == "<END>": second_end_f = True

        if not first_end_f:
            first_list.append(first)
        if not second_end_f:
            second_list.append(second)
    return LineProviderFromArray(first_list), \
           LineProviderFromArray(second_list)

def test(line_pair_text):
    subject, nominal = line_list_pair(line_pair_text)
    print(line_pair_text)
    print(main.judge(config, subject, nominal))

if "lines" in sys.argv:
    test("""
    :                     A  : A :
    """)
    test("""
    :                        : A :
    """)
    test("""
    :                     A  :   :
    """)
    test("""
    :                     A  : B :
    :                     B  :   :
    """)
    test("""
    :                     B  : A :
    :                        : B :
    """)
    test("""
    :                     A  : A :
    :                     B  : B :
    """)

if "potpourri" in sys.argv:
    test("""
    :      ||||                : |||| :
    :      otto                : fritz :
    :      fritz               : otto :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :      otto                :       :
    :      fritz               : otto :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :      otto                : fritz :
    :                          : otto :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :      otto                : fritz :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :      otto                : otto :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :                          : otto :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :      otto                :      :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :                          :      :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :                          ::
    :      ||||                : |||| :
    """)
    test("""
    :      ||||                : |||| :
    :::
    :      ||||                : |||| :
    """)


if "chunk_pipe" in sys.argv:
    pass
