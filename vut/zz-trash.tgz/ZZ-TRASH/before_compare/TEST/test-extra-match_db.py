#
# PURPOSE: 'MatchDb' -- map: ia --> (ib, analogy list)
#
#
# SPDX-Linces: MIT; (C) Frank-Rene Schaefer.
#______________________________________________________________________________

import sys
import os
import re

this_directory = os.path.join(os.path.dirname(sys.argv[0]), "../../../../")
sys.path.insert(0, this_directory)

from   hwut.engine.compare.friends_pairing_match_db import MatchDb
from   hwut.engine.compare.analogy_db               import AnalogyDb, ConsistentAnalogyList

if "--hwut-info" in sys.argv:
    print("MatchDb: Extra tests;")
    print("CHOICES: analogy_interferences;")
    sys.exit()

if "analogy_interferences" in sys.argv:
    def test(match_db, analogy_db):
        print("--------------------------------")
        print("BEFORE: {")
        print(match_db)
        print("}")

        match_db_2 = MatchDb(match_db)
        verdict = match_db.filter_analogy_interference(analogy_db, abort_f=False)

        print("AFTER: --> %s {" % verdict)
        print(match_db)
        print("}")

        verdict = match_db_2.filter_analogy_interference(analogy_db, abort_f=True)
        print("AFTER(abort=True): --> %s {" % verdict)
        if verdict:
            print(match_db_2)
        print("}")

    match_db = MatchDb([
        # ia: ib:   analogy_list:
        (1,   [
            (100, ConsistentAnalogyList.from_list([("otto", "fritz"), ("lucia", "anabella")])),
            (101, ConsistentAnalogyList.from_list([("otto", "heinz")]))
        ]),
        (3,   [
            (101, ConsistentAnalogyList.from_list([("otto", "heinz"), ("lucia", "anabella")])),
            (100, ConsistentAnalogyList.from_list([("otto", "fritz")]))
        ])
    ])



    test(match_db, AnalogyDb.from_dict({ "otto":  "fritz" }))
    test(match_db, AnalogyDb.from_dict({ "otto":  "egon", "lucia": "diana" }))
