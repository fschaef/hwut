#! /usr/bin/env python3
#
#______________________________________________________________________________

import sys
import os
import re

sys.path.insert(0, "../../../../")

import hwut.engine.compare.comperator      as     comperator
import hwut.engine.compare.comparison_info as     comparison_info
from   hwut.engine.compare.analogy_db      import AnalogyDb
from   hwut.engine.compare.tolerance       import Processor, E_ToleranceId
from   hwut.engine.compare.tolerance_match import MatchLine


if "--hwut-info" in sys.argv:
    print("Tolerance: Processor;")
    print("CHOICES: judge, analyze, cost, cost-seq;")
    sys.exit()


def empty_config():
    config = comperator.Configuration
    config.analogy_f               = False
    config.whitespace_f            = False
    config.backslash_f             = False
    config.numeric_tolerance_ratio = 0
    config.equivalent_pattern_list      = []
    return config

def show(processor):
    print()
    print("size: %i;" % len(processor))
    for tolerance in processor:
        if tolerance.pattern is None: pattern = "None"
        else:                         pattern = tolerance.pattern.pattern
        print("%s -> %s" % (pattern, processor.comperator_match.compare_function_db[tolerance.id].__name__))

if True or "cmp_info_iterable" in sys.argv:
    config = empty_config()
    config.numeric_tolerance_ratio = 0.1
    config.analogy_f = True
    config.backslash_f = True
    config.whitespace_f = True
    config.equivalent_pattern_list = [ r"hallo|hi", r"hello|bonjour" ]
    processor = Processor(config)

    def test(name, subject_line, nominal_line):
        print("--( %s )-------\n" % name)
        print("subject: '%s'" % subject_line)
        print("nominal: '%s'" % nominal_line)
        print()
        analogy_db = AnalogyDb()
        subject_match_list = processor.create_MatchLine(subject_line, 66)
        nominal_match_list = processor.create_MatchLine(nominal_line, 4711)
        iterable = comparison_info.do(subject_match_list,
                                      nominal_match_list,
                                      analogy_db)
        for verdict in iterable:
            print("  %s" % verdict)
        print()

    test("subject exhausts",   "a",             "a 4771 hi")
    test("nominal exhausts",   "a 4771 hi",     "a")
    test("subject plug 1",     "a a b",         "a b")
    test("nominal plug 1",     "b",             "a b")
    test("subject plug 2",     "b",             "a a b")
    test("nominal plug 2",     "a a b",         "b")
    test("cmp. string true",   "spass",         "spass")
    test("cmp. string false",  "spass",         "spiel")
    test("cmp. analogy true",  "((1)) ((2)) ((1)) ((2))", "((A)) ((B)) ((A)) ((B))")
    test("cmp. analogy true",  "((1)) ((A))",   "((A)) ((1))")
    test("cmp. analogy false", "((1)) ((2))",   "((A)) ((A))")
    test("cmp. number true",   "4711",          "4712")
    test("cmp. number false",  "-1e37",         "1e37")
    test("cmp. backslash must always be true",  "///",  "\\/")
    test("cmp. whitespace must always be true", "\t   ",  "\t ")
    test("cmp. pattern true",  "hallo",         "hi")
    test("cmp. pattern false", "hallo",         "bonjour")
    test("cmp. pattern false", "hello",         "hallo")

