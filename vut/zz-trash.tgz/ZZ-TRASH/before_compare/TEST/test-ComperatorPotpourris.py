#! /usr/bin/env python3
#
# PURPOSE: 'ComperatorLines' -- comparing two lines on equivalence.
#
# The basis for tolerant comparison is the analysis of the nominal line as
# it is provided by the 'GOOD' recording. Tolerance patterns identified in
# the nominal may then be searched for in the subject line (i.e. the current
# output of the test application). If the subject line matches the patterns
# at the same position and the tolerance comparison succeeds, the two lines
# are considered equivalent.
#
# This test focusses on the analysis of the 'nominal_line' and the 'subject
# line'.
#
# SPDX-Linces: MIT; (C) Frank-Rene Schaefer.
#______________________________________________________________________________

import sys
import os
import re
from itertools import zip_longest

sys.path.insert(0, "../../../../")

import hwut.engine.compare.comperator           as     comperator
from   hwut.engine.compare.tolerance            import E_Verdict, Processor
from   hwut.engine.compare.tolerance_match      import MatchLine
from   hwut.engine.compare.analogy_db           import AnalogyDb
from   hwut.engine.compare.comperator_potpourri import ComperatorPotpourri

if "--hwut-info" in sys.argv:
    print("ComperatorPotpourri;")
    print("CHOICES: judge, cmp_info_list-good, cmp_info_list-bad, cmp_info_list-bad-2;")
    sys.exit()

config = comperator.Configuration()
config.equivalent_pattern_list = [ r"happy|funny", r"I|me" ]
config.potpourri_max_comparison_count = 10

pc = ComperatorPotpourri(config, AnalogyDb())
processor = Processor(config)

def _line_info_prepare(line_text_list, start):
    return [
        (line_n, line_text)
        for line_n, line_text in enumerate(line_text_list, start)
    ]

def _line_info_list(line_text_list, start):
    return [
        processor.create_MatchLine(line_text, line_n)
        for line_n, line_text in enumerate(line_text_list, start)
    ]

def prepare(line_info):
    if line_info is not None: return "%03i" % line_info[0], line_info[1]
    else:                     return "   ", "<empty>"

def print_this(subject_line_list, nominal_line_list):
    print("--------------------------------")
    L = max(len(line) for line in (["         "] + subject_line_list))
    print("   subject: %s   nominal:" % (" " * (L - len("subject:"))))
    for subject_line_info, nominal_line_info in zip_longest(subject_line_list, nominal_line_list):
        ia_str, subject_line = prepare(subject_line_info)
        ib_str, nominal_line = prepare(nominal_line_info)
        print("   [%s] '%s' %s [%s] '%s'" % (ia_str, subject_line,
                                             " " * (L - len(subject_line)),
                                             ib_str, nominal_line))

def test_comparison_info(orig_subject_line_list, orig_nominal_line_list):
    pre_subject_line_list = _line_info_prepare(orig_subject_line_list, 100)
    pre_nominal_line_list = _line_info_prepare(orig_nominal_line_list, 1000)
    print_this(pre_subject_line_list, pre_nominal_line_list)

    subject_line_list = _line_info_list(orig_subject_line_list, 100)
    nominal_line_list = _line_info_list(orig_nominal_line_list, 1000)

    subject_line_n_to_index = dict((entry.line_n, i) for i, entry in enumerate(subject_line_list))
    nominal_line_n_to_index = dict((entry.line_n, i) for i, entry in enumerate(nominal_line_list))

    pc.analogy_db.clear()

    result = pc.comparison_info(subject_line_list, nominal_line_list)
    assert len(result) == max(len(subject_line_list), len(nominal_line_list))

    print()
    print("Verdict: %s" % result.verdict_id)
    print()

    def _number(number):
        if number is not None: return "%02i" % number
        else:                  return "  "

    for cmp_info_list in result:
        verdict_id = cmp_info_list.verdict_id
        ia         = cmp_info_list.subject_line_n
        ib         = cmp_info_list.nominal_line_n

        if verdict_id == E_Verdict.SUCCESS: verdict_str = "     "
        else:                                 verdict_str = " BAD "

        if ia is not None: text_a = orig_subject_line_list[subject_line_n_to_index[ia]]; ia_str = "%02i" % ia
        else:              text_a = "==== None ====";                                    ia_str = "--"
        if ib is not None: text_b = orig_nominal_line_list[nominal_line_n_to_index[ib]]; ib_str = "%02i" % ib
        else:              text_b = "==== None ====";                                    ib_str = "--"

        print("%s[%s] %s%s --> [%s] %s" % (verdict_str,
                                           ia_str, text_a, " " * (15 - len(text_a)),
                                           ib_str, text_b))
    # The determination of a verdict list is not subject of this test.
    # this has been accomplished in tests for 'tolerance.py' and
    # 'tolerance-match_db.py'.
    ### if cmp_info_list:
    ###            for verdict in cmp_info_list:
    ###                print("       %s" % verdict)

def test_judge(subject_line_list, nominal_line_list):

    pre_subject_line_list = _line_info_prepare(subject_line_list, 100)
    pre_nominal_line_list = _line_info_prepare(nominal_line_list, 1000)
    print_this(pre_subject_line_list, pre_nominal_line_list)

    subject_line_list = _line_info_list(subject_line_list, 100)
    nominal_line_list = _line_info_list(nominal_line_list, 1000)

    total_verdict = pc.judge(subject_line_list, nominal_line_list)

    print("association: %s" % total_verdict)

if "judge" in sys.argv:
    test_judge(["otto", "fritz"],  ["otto", "fritz"])
    test_judge(["otto", "fritz"],  ["otto", ""])
    test_judge(["otto", "fritz"],  ["otto"])
    test_judge(["funny", "fritz"], ["otto",  "happy"])
    test_judge([],                 [])

if "cmp_info_list-good" in sys.argv:
    test_comparison_info(["otto", "fritz"],
                         ["otto", "fritz"])
    test_comparison_info(["happy", "fritz"],
                         ["fritz", "funny"])
    test_comparison_info(["happy", "mummie", "me smart", "fritz"],
                         ["fritz", "mummie", "I smart", "funny"])
    test_comparison_info(["me happy", "((4)) ((3))", "I happy", "((3))"],
                         ["((1)) ((5))", "me happy", "I funny", "((5))"])
    test_comparison_info(["((1))", "((2))", "((3))", "((1))"],
                         ["((C))", "((A))", "((B))", "((A))"])
    test_comparison_info(["((1))", "((2))", "((3))", "((1))"],
                         ["((1))", "((2))", "((3))", "((1))"])

if "cmp_info_list-bad" in sys.argv:
    test_comparison_info(["", ""],                        ["fritz","otto"])
    test_comparison_info(["otto is happy", "me not"],     ["I yes","otto is funny"])
    test_comparison_info(["((is)) happy", "((is)) nice"], ["((was)) nice","((will)) funny"])
    test_comparison_info(["((is)) happy", "((is)) nice"], ["((will)) nice","((was)) funny"])

if "cmp_info_list-bad-2" in sys.argv:
    test_comparison_info(["%i" % i for i in range(70)],
                         ["%s" % chr(i%26+ord('A')) for i in range(60)])

