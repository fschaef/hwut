#! /usr/bin/env python3
#
# PURPOSE: 'ComperatorLines' -- comparing two lines on equivalence.
#
# The basis for tolerant comparison is the analysis of the nominal line as
# it is provided by the 'GOOD' recording. Tolerance patterns identified in
# the nominal may then be searched for in the subject line (i.e. the current
# output of the test application). If the subject line matches the patterns
# at the same position and the tolerance comparison succeeds, the two lines
# are considered equivalent.
#
# This test focusses on the analysis of the 'nominal_line' and the 'subject
# line'.
#
# SPDX-Linces: MIT; (C) Frank-Rene Schaefer.
#______________________________________________________________________________

import sys
import os
import re

sys.path.insert(0, "../../../../")

import hwut.engine.compare.comperator       as     comperator
from   hwut.engine.compare.comperator_lines import ComperatorLines
from   hwut.engine.compare.tolerance        import Processor

if "--hwut-info" in sys.argv:
    print("ComperatorLines;")
    print("CHOICES: judge, cmp_info_list;")
    sys.exit()

config = comperator.Configuration()
config.equivalent_pattern_list = [ r"funny|happy", r"funny|glad", r"I|me" ]

lc = ComperatorLines(config)
processor = Processor(config)

if "judge" in sys.argv:
    def test(subject_line, nominal_line):
        print()
        print("subject: '%s'" % subject_line)
        print("nominal: '%s'" % nominal_line)
        print("=>       %s"   % lc.judge(processor.create_MatchLine(subject_line, 66),
                                         processor.create_MatchLine(nominal_line, 4711)))

    test("a", "b")
    test("happy me", "funny I")
    test("glad me", "funny I")
    test("funny me", "funny I")
    test("happy me", "glad I")

if "cmp_info_list" in sys.argv:
    def test(subject_line, nominal_line):
        print()
        print("subject: '%s'" % subject_line)
        print("nominal: '%s'" % nominal_line)
        result = lc.comparison_info(processor.create_MatchLine(subject_line, 66),
                                    processor.create_MatchLine(nominal_line, 4711))
        print("=> %s" % result.verdict_id)
        for verdict in result:
            print("  %s" % verdict)

    test("hallo", "hallo")
    test("happy me", "funny I")
    test("happy me", "funny more me")
    test("happy more fun me", "funny me")
    test("happy me", "funny")
    test("happy", "funny I")

