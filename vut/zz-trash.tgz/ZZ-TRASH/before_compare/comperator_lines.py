from   hwut.engine.compare.comperator       import Comperator, \
                                                   Configuration
from   hwut.engine.compare.tolerance        import Processor, \
                                                   E_Verdict
from   hwut.engine.compare.tolerance_match  import CmpInfoLine, \
                                                   MatchLine
from   hwut.engine.compare.analogy_db       import AnalogyDb
from   hwut.engine.compare.friends_pairing  import FriendsPairing
from   hwut.engine.quex.typed               import typed
import hwut.engine.tools                    as     tools

import re
from   itertools import zip_longest, islice

class ComperatorMisfit(Comperator):
    def judge(self, a, b) -> bool:
        return False

    def comparison_info(self, a, b):
        return CmpInfoLine(None, None, [], E_Verdict.MISFIT)

    def cost(self, a, b):
        return (1e37, 1e37)


class ComperatorLines(Comperator):
    """A 'ComperatorLines' is a comperator for pairs of lines consisting of
    character strings. The comperator does not only compare plain equality.
    It applies a list of tolerance procedures. A tolerance procedure
    identifies patterns in a string and possibly consider them as equivalent.

    For example, the 'Number' tolerance allows for a predefined lack of
    numeric precision. If a line contains two numbers at the same position
    and those numbers do not differ more than what is admissible, the two
    lines are still equivalent.

    The main two functions of this class are '.judge()' and '.comparison_info()'.
    The former reports if two lines are equivalent. The latter provides a
    list of 'CmpInfoMatch' objects which tell in detail, where patterns in the
    lines where identified and if they were equivalent.
    """
    @typed(config=Configuration)
    def __init__(self, config):
        # Tolerance table defines the sequence in which tolerance concepts
        # are applied. It also contains for each concept a '.compare()'
        # function which is applied on each pair of identified patterns.
        self.processor  = Processor(config)
        self.analogy_db = AnalogyDb()

    @typed(subject_match_line=MatchLine, nominal_match_line=MatchLine)
    def judge(self, subject_match_line, nominal_match_line):
        """RETURNS: True,  if both lines are equivalent.
                           (new entries in analogy_db, have potentially been made)
                    False, else.

        UPDATES: internal analogy_db, if successful.
        """
        return self.processor.judge(subject_match_line, nominal_match_line,
                                    self.analogy_db)

    @typed(subject_match_line=MatchLine, nominal_match_line=MatchLine)
    def comparison_info(self, subject_match_line, nominal_match_line):
        """RETURNS: CmpInfoLine

        Gives detailed information about the verdicts that make up the comparison.
        That is, it also provides the position of the sub-strings where they occurr.
        """
        cmp_info_list = tuple(self.processor.cmp_info_iterable(subject_match_line,
                                                               nominal_match_line,
                                                               self.analogy_db))
        return CmpInfoLine(subject_match_line.line_n, nominal_match_line.line_n,
                           cmp_info_list)

