"""PURPOSE: Comparing two input streams: 'subject' and 'nominal'

The stream 'subject' is supposed to be the output of a test application.  The
stream 'nominal' is the stored-away reference output of a good test run. Input
is compared line-wise or potpourri-wise. Potpourri-wise means that a sequence
of lines is considered as a block. A potpourri in the subject must contain the
same lines as the potpourri in the nominal in order to be equivalent. The
sequence in which they appear is irrelevant.

Two functions build the interface of this module:

  judge(subject_fh, nominal_fh) -> bool

     returns 'True' if both streams are equivalent, 'False' else.

  cmp_info_iterable(subject_fh, nominal_fh)

     yields comparison information about the lines and potpourris that appear
     in the input streams.

AUTHOR: Frank-Rene Schaefer
SPDX-Linces: MIT
"""
from hwut.engine.tools                        import HwutIterator
from hwut.engine.compare.analogy_db           import AnalogyDb
from hwut.engine.compare.tolerance            import Processor
from hwut.engine.compare.tolerance_match      import E_Verdict, CmpInfoLine, CmpInfoPotpourri, MatchLine
from hwut.engine.compare.comperator_lines     import ComperatorLines, ComperatorMisfit
from hwut.engine.compare.comperator_potpourri import ComperatorPotpourri

from itertools import zip_longest, chain

class Engine:
    def __init__(self, config, subject_line_provider, nominal_line_provider):
        self.analogy_db           = AnalogyDb()
        self.comperator_lines     = ComperatorLines(config, self.analogy_db)
        self.comperator_potpourri = ComperatorPotpourri(config, self.analogy_db)
        self.comperator_misfit    = ComperatorMisfit()
        self.processor            = Processor(config)

        self.subject_line_provider = subject_line_provider
        self.nominal_line_provider = nominal_line_provider

        self.subject_iterable = None
        self.nominal_iterable = None

    def iterator(self):
        """An iterator that provides pairs of subject and nominal lines in pairs.
        """
        self.subject_iterable = self._chunk_pipe(self.subject_line_provider)
        self.nominal_iterable = self._chunk_pipe(self.nominal_line_provider)
        return zip_longest(self.subject_iterable, self.nominal_iterable)

    def hwut_iterator(self):
        """An iterator like '.iterator()', but which allows to search forwards,
        and undo previous steps.
        """
        self.subject_iterable = HwutIterator(self._chunk_pipe(self.subject_line_provider))
        self.nominal_iterable = HwutIterator(self._chunk_pipe(self.nominal_line_provider))
        return zip_longest(self.subject_iterable, self.nominal_iterable)

    def judge(self, subject_chunk, nominal_chunk):
        comperator = self._get_comperator(subject_chunk, nominal_chunk)
        return comperator.judge(subject_chunk, nominal_chunk)

    def comparison_info(self, subject_chunk, nominal_chunk):
        """RETURNS: [0] True, if subject_chunk and nominal_chunk are equivalent (good)
                        False, else.
                    [1] CmpInfoLine,     if chunk was a line.
                        CmpInfoPotpourri if chunk was a potpourri
        """
        comperator = self._get_comperator(subject_chunk, nominal_chunk)
        return comperator.comparison_info(subject_chunk, nominal_chunk)

    def more_similar(self, subject_chunk, auxiliary, walk_distance):
        """RETURNS: True, if subject and nominal chunk have no major differences.
                    False, else.
        """
        def _cost(subject_chunk, nominal_chunk):
            return self.comparison_info(subject_chunk, nominal_chunk).cost()

        nominal_chunk, max_cost = auxiliary
        if type(nominal_chunk) != type(subject_chunk): # Always 'line' != 'potpourri'
            return False
        else:
            # The cost increases with walking distance => prefer chunks closer ahead.
            cost = _cost(subject_chunk, nominal_chunk)
            cost = (cost[0] * walk_distance / 10, cost[1] * walk_distance / 10)
            return cost < max_cost

    def subject_plug_sequence(self, subject_plug_seq, subject_last, nominal):
        def _expand(subject_plug):
            if isinstance(subject_plug, MatchLine):
                return CmpInfoLine.SUBJECT_PLUG(subject_plug)
            else:
                return CmpInfoPotpourri.SUBJECT_PLUG(subject_plug)

        yield from (_expand(plug) for plug in subject_plug_seq)

        assert type(nominal) == type(subject_last)
        yield self.comparison_info(subject_last, nominal)

    def nominal_plug_sequence(self, nominal_plug_seq, nominal_last, subject):
        def _expand(nominal_plug):
            if isinstance(nominal_plug, MatchLine):
                return CmpInfoLine.NOMINAL_PLUG(nominal_plug)
            else:
                return CmpInfoPotpourri.NOMINAL_PLUG(nominal_plug)

        yield from (_expand(plug) for plug in nominal_plug_seq)

        assert type(subject) == type(nominal_last)
        yield self.comparison_info(subject, nominal_last)

    def _get_comperator(self, subject_chunk, nominal_chunk):
        """RETURNS: 0 - no common chunk type
                    1 - common chunk type = line text
                    2 - common chunk type = potpourri
        """
        if subject_chunk is None or nominal_chunk is None:
            return self.comperator_misfit

        subject_line_f = isinstance(subject_chunk, MatchLine)
        nominal_line_f = isinstance(nominal_chunk, MatchLine)

        if subject_line_f != nominal_line_f:
            return self.comperator_misfit

        elif subject_line_f:
            return self.comperator_lines

        else:
            assert all(isinstance(m, MatchLine) for m in subject_chunk)
            assert all(isinstance(m, MatchLine) for m in nominal_chunk)
            return self.comperator_potpourri

    def _chunk_pipe(self, line_provider):
        """Generates 'chunks' from lines of the line provider. A chunk can either
        be a single line or a potpourri (bracketted by '||||' lines).

        The 'line_provider' must implement the '.get()' function. It returns
        'None' as soon as no more input is present. It is not supposed to block!

        YIELDS: (line number, line text)         if text element was a line.
                list of (line number, line text) if text element is a potpourri.
        """
        def _next(line_n, line_provider):
            return line_n + 1, line_provider.get()

        def _irrelevant(line):
            line = line.strip()
            if not line:
                return True
            elif line.startswith("##"):
                return True
            elif line.endswith("##"):
                return True
            else:
                return False

        line_n = 0
        while 1 + 1 == 2:
            line_n, line = _next(line_n, line_provider)
            if line is None:
                return
            if _irrelevant(line):
                continue
            elif line.strip() != "||||":
                yield self.processor.create_MatchLine(line, line_n)
            else:
                line_n, line = _next(line_n, line_provider)
                start_line_n = line_n
                chunk        = []
                while line.strip() != "||||":
                    if line is None:
                        start_line_n = None
                        chunk        = None
                        break
                    elif not _irrelevant(line):
                        chunk.append(self.processor.create_MatchLine(line, line_n))
                    line_n, line = _next(line_n, line_provider)
                yield chunk


def judge(config, subject_line_provider, nominal_line_provider) -> bool:
    """RETURNS: True, if subject and nominal stream are equivalent.
                False, else.

    The function operates on coroutines reading lines from line providers.
    As soon as 'False' can be stated it aborts immediately-not consuming
    any further input. Caller functions then, might then terminate the data
    producing process.

    ONLY REQUIREMENT: line provider member function '.get()'.

    The '.get()' function either returns a line of text or 'None' in case
    that the stream terminated.
    """
    engine = Engine(config, subject_line_provider, nominal_line_provider)

    # chunk: (line_n, line text)         if the chunk is a normal input line.
    #        list of (line_n, line text) if the chunk is potpourri.
    return all(engine.judge(subject_chunk, nominal_chunk)
               for subject_chunk, nominal_chunk in engine.iterator())

def comparison_info(config, subject_line_provider, nominal_line_provider):
    """YIELDS: Comparison results between subject and nominal lines.

    This function iterates over subject and nominal lines and compares
    them. When lines are too deviant from each other, 'plugs' in one
    sequence are inserted until it fits again the other sequences.
    """
    engine = Engine(config, subject_line_provider, nominal_line_provider)

    # chunk: (line_n, line text)         if the chunk is a normal input line.
    #        list of (line_n, line text) if the chunk is potpourri.
    # => verdict: (verdict, CmpInfoLine)
    #             list of (verdict, CmpInfoLine)
    for subject, nominal in engine.hwut_iterator():
        # (1) Are subject and nominal the same?
        #     => directly report verdict
        cmp_info = engine.comparison_info(subject, nominal)
        if cmp_info.verdict_id == E_Verdict.SUCCESS:
            yield cmp_info
            continue

        cost = cmp_info.cost()

        # (2) If lines are very much different, assume that their comparison
        #     is inappropriate. Try to find a line-up that fits.

        # Search subject ahead matching current nominal (nominal lines missing?)
        # Search nominal ahead matching current subject (subject lines missing?)
        subject_plug_seq, \
        subject_last             = engine.subject_iterable.collect_until((nominal, cost),
                                                                         engine.more_similar)
        nominal_plug_seq, \
        nominal_last             = engine.nominal_iterable.collect_until((subject, cost),
                                                                         engine.more_similar)

        if   subject_plug_seq is None and nominal_plug_seq is None:
            yield cmp_info
        elif _subject_sequence_is_shorter(subject_plug_seq, nominal_plug_seq):
            subject_plug_seq = chain([subject], subject_plug_seq)
            yield from engine.subject_plug_sequence(subject_plug_seq, subject_last, nominal)
        else:
            nominal_plug_seq = chain([nominal], nominal_plug_seq)
            yield from engine.nominal_plug_sequence(nominal_plug_seq, nominal_last, subject)

def _subject_sequence_is_shorter(subject_plug_seq, nominal_plug_seq):
    if subject_plug_seq is not None and nominal_plug_seq is None:
        return True
    elif subject_plug_seq is None and nominal_plug_seq is not None:
        return False
    elif len(subject_plug_seq) < len(nominal_plug_seq):
        return True
    else:
        return False


