from hwut.engine.compare.comperator       import Comperator, Configuration
from hwut.engine.compare.comperator_lines import ComperatorLines
from hwut.engine.compare.friends_pairing  import FriendsPairing, FriendsPairingFailQuickly
from hwut.engine.compare.tolerance_match  import MatchLine, \
                                                 CmpInfoPotpourri
from hwut.engine.compare.tolerance        import Processor, \
                                                 E_Verdict
from hwut.engine.quex.typed               import typed

from copy import copy

class ComperatorPotpourri(Comperator):
    """Comperator for *potpourris*.

    The 'potpourri' is a type of line-wise tolerance. That is, the lines
    occurring inside a potpourri do not have to appear in the same order
    as in the nominal file. For example,

         Test output:                    Reference:

         ||||                            ||||
         Camera detected Otto.           Automatic door opened.
         Automatic door opened.          Light in kitchen activated.
         Light in kitchen activated.     Camera detected Otto.
         ||||                            ||||

    are equivalent, because for any line in 'Test output' there exists
    a line in 'Reference', even though, they do not appear in the same
    order.

    The 'ComperatorPotpourri' considers all types of string tolerances
    implemented in 'ComperatorLines', **except for analogies**.
    """
    def __init__(self, config, analogy_db):
        self.processor            = Processor(config)
        self.max_comparison_count = config.potpourri_max_comparison_count
        self.analogy_db           = analogy_db

    @typed(subject_match_line_list=[MatchLine], nominal_match_line=[MatchLine])
    def judge(self, subject_match_line_list, nominal_match_line_list):
        """
        subject_match_line_list: list of (line number, line text)
        nominal_match_line_list: list of (line number, line text)

        RETURNS: True, if for each string in 'match_line_list_a' exists a string in
                       'match_line_list_b' that is equivalent.
                 False, else.
        """
        if len(subject_match_line_list) != len(nominal_match_line_list):
            return False

        verdict, _, _ = FriendsPairingFailQuickly(self.processor,
                                                  subject_match_line_list,
                                                  nominal_match_line_list).do(self.analogy_db)

        return verdict

    @typed(subject_match_line_list=[MatchLine], nominal_match_line=[MatchLine])
    def comparison_info(self, subject_match_line_list, nominal_match_line_list):
        """Delivers information about verdicts have been achieved.

        subject_match_line_list: list of MatchLine objects
        nominal_match_line_list: list of MatchLine objects

        RETURNS: [0] True, if both potpourris are equivalent,
                     False, else.
                 [1] list of CmpInfoLine-s

        where 'ia' is the index of 'match_line_list_a' and 'ib' the index of
        'match_line_list_b' of two associated lines. The 'cmp_info_iterable' contains
        verdict objects documenting the details of comparison.
        """
        # Build map: line index --> line number in input source
        pairing = FriendsPairing(self.processor,
                                 subject_match_line_list, nominal_match_line_list)

        verdict, couples, self.analogy_db = pairing.do(self.analogy_db)
        # 'analogy_db': determined by the paired equivalent couples!
        # No other process influences the content of the 'analogy_db'.

        cmp_info_line_list = pairing.pair_maximum(couples, self.analogy_db,
                                                  self.max_comparison_count)

        return CmpInfoPotpourri(cmp_info_line_list,
                                E_Verdict.from_bool(verdict))

