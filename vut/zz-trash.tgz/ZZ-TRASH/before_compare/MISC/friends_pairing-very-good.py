"""
SPDX-Linces: MIT; (C) 2021 Frank-Rene Schaefer
"""
from   hwut.engine.compare.analogy_db import AnalogyDb

from   itertools   import zip_longest
from   collections import defaultdict

class LineDb:
    """Map: line index --> (line as string, line as 'Match' sequence)
    """
    def __init__(self, line_list, tolerance_table):
        """Maintains plain strings of lines and 'match_list'. The
        match list is only generated on demand.
        """

        # 'analyze_generator()' returns a generator.
        # It does nothing until it is applied.
        self.line_db         = dict((line_i, line) for line_i, line in enumerate(line_list))
        self.match_list_db   = {}
        self.tolerance_table = tolerance_table

    def __len__(self):
        return len(self.line_db)

    def __iter__(self):
        yield from self.line_db

    def get_match_list(self, line_i):
        """RETURNS: match list for line of index 'line_i'.

        Generators must now be replaced with lists. Otherwise, they
        cannot be referred more than once.
        """
        match_list = self.match_list_db.get(line_i)
        if match_list is None:
            match_list = list(self.tolerance_table.raw_match_list(self.line_db[line_i]))
            self.match_list_db[line_i] = match_list
        return match_list

    def line_items(self):
        """YIELDS: (line index, line) of all lines in the database.
        """
        yield from self.line_db.items()

    def match_list_items(self):
        """YIELDS: (line index, match list)

        for all items in 'self'. Generators which are not yet converted
        to lists are converted (but not entered).
        """
        for line_i in self.line_db.keys():
            match_list = self.get_match_list(line_i)
            yield line_i, match_list


class FriendsPairing:
    def __init__(self, tolerance_table, subject_line_list, nominal_line_list):
        self.tolerance_table = tolerance_table
        self.subject_db  = LineDb(subject_line_list, tolerance_table) # line index -> line, match_list
        self.nominal_db  = LineDb(nominal_line_list, tolerance_table) # line index -> line, match_list

        self.nominal_lines_with_analogy = set(
             ib
             for ib, nominal_line in self.nominal_db.line_db.items()
             if self.tolerance_table.has_analogy(nominal_line)
        )

    def do(self):
        """RETURNS: [0] verdict
                    [1] map: 'ia' --> 'ib'
                    [2] analogy_db

        Where 'ia' is the index of a line in 'subject_lines' that is equivalent
        and, thus, associated with 'ib' which is a line from 'nominal_lines'.
        """
        match_db                      = self._get_match_db()
        match_db, couples, analogy_db = _extract_ultimates(match_db)

        return self._core(match_db, couples, analogy_db)

    def _core(self, match_db, couples, analogy_db):
        """L:         size of 'couples' if solution is complete.
           match_db:  map: 'ia' --> ('ib', required list of analogies)
           couples:   map: 'ia' --> 'ib'

        That is, 'couples' captured already the individuals for which there is
        no alternative than each other.

        RETURNS: [0] True, if solution covers all subject and nominal lines.
                     False, else.
                 [1] map: 'ia' --> 'ib'
                 [2] analogy_db
        """
        L = max(len(self.subject_db), len(self.nominal_db))
        if not match_db:
            return len(couples) == L, couples, analogy_db

        subject_singles_all = set(match_db.keys())

        work_list = [
            (ia, couples, analogy_db) for ia in match_db.keys()
        ]
        best_size = 0; best_couples = {}; best_analogy_db = AnalogyDb()
        while work_list:
            ia, couples, analogy_db = work_list.pop()

            nominals_taken = set(couples.values())
            nominal_singles = [
                (ib, analogy_list)
                for ib, analogy_list in match_db[ia] if ib not in nominals_taken
            ]
            new_subject_singles = subject_singles_all.difference(couples.keys())
            new_subject_singles.remove(ia)
            for ib, analogy_list in nominal_singles:
                if not analogy_db.is_consistent(analogy_list):
                    continue
                elif len(couples) == L - 1:
                    couples[ia] = ib
                    return True, couples, analogy_db.absorb(analogy_list)
                new_analogy_db      = analogy_db.clone_update(analogy_list)
                new_couples         = dict(couples)  # isolate 'couple' database
                new_couples[ia]     = ib
                if len(new_couples) > best_size:
                    best_size       = len(new_couples)
                    best_couples    = new_couples
                    best_analogy_db = new_analogy_db
                work_list.extend(
                    (ia, new_couples, new_analogy_db)
                    for ia in new_subject_singles
                )
        return False, best_couples, best_analogy_db

    def _matches(self, ia, subject_line):
        """YIELDS: [0] 'ib' from 'nominal_available' where
                       subject_line_list[ia] matchs nominal_line_list[ib]
                   [1] list of analogies required for the equivalence to hold.
        """
        for ib, nominal_line in self.nominal_db.line_items():
            # If no analogies are involved, a plain match is sufficient
            if ib not in self.nominal_lines_with_analogy:
                if subject_line == nominal_line:
                    yield ib, []
                    continue

            subject_match_list = self.subject_db.get_match_list(ia)
            nominal_match_list = self.nominal_db.get_match_list(ib)
            verdict, \
            analogy_list = self.tolerance_table.judge(subject_match_list,
                                                      nominal_match_list)

            if verdict:
                yield ib, analogy_list

    def _get_match_db(self, abort_f=False):
        match_db = dict()
        for ia, subject_line in self.subject_db.line_items():
            mate_list = list(self._matches(ia, subject_line))
            if not mate_list:
                if abort_f: return None
                else:       continue
            match_db[ia] = mate_list
        return match_db

class FriendsPairingFailQuickly(FriendsPairing):
    def __init__(self, tolerance_table, subject_line_list, nominal_line_list):
        FriendsPairing.__init__(self, tolerance_table, subject_line_list, nominal_line_list)

    def do(self):
        """RETURNS: [0] verdict
                    [1] map: 'ia' --> 'ib'
                    [2] analogy_db

        Where 'ia' is the index of a line in 'subject_lines' that is equivalent
        and, thus, associated with 'ib' which is a line from 'nominal_lines'.
        """
        if len(self.subject_db) != len(self.nominal_db):
            return None

        match_db = self._get_match_db(abort_f=True)
        # 'match_db' is None if not all subjects are present
        if match_db is None:
            return False, None, None

        if _count_nominals(self, match_db) != len(self.nominal_db):
            return None, None, None

        match_db, couples, analogy_db = _extract_ultimates(match_db, abort_f=True)

        if match_db is None:
            return False, None, None

        return self._core(match_db, couples, analogy_db)

    def _count_nominals(match_db):
        nominals_found = set()
        for ia, mate_list in match_db.items():
            nominals_found.update(ib for ib, _ in mate_list)
        return len(nominals_found)

def _extract_ultimates(match_db, abort_f=False):
    """Search for entries in 'match_db' where there is only one possible
    mate. Those entries are extracted into the 'couples' database.

    RETURNS: [0] adapted 'match_db'
             [1] 'couples': ia --> ib
                 for those 'ia' and 'ib' for which there is no alternative.
             [2] 'analogy_db' of required analogies to hold for 'couples'
                 to match.

    The 'abort_f' controls what has to happen as soon at it becomes clear
    that a perfect solution is impossible. If set 'True' the function
    reacts immediately by returning '(None, None, None)'.
    """
    def _find_couples(match_db, couples):
        """Find 'ia'-s which have only one possible matching 'ib'. Extract
        them into 'couples', Elements in 'couples' do not participate in the
        later matching procedure.

        RETURNS: [0] True, if 'ia' are either in match_db or couples.
                     False, some 'ia' dropped out completely
                 [1] 'ib'-s that have been coupled.

        These 'ib'-s may occur in other match entries and need now to be
        removed from there.
        """
        ok_f = True
        nominals_coupled = set()
        for ia, mate_list in list(match_db.items()):
            if len(mate_list) > 1:
                continue
            ib, analogy_list = mate_list[0]
            del match_db[ia]
            if ib in nominals_coupled:
                ok_f = False
            elif not analogy_db.update_if_consistent(analogy_list):
                ok_f = False
            couples[ia] = ib
            nominals_coupled.add(ib)
        return ok_f, nominals_coupled

    def _find_couples_inverse(match_db, couples, analogy_db):
        """Find 'ib'-s that have only one possible matching 'ia'. Extract
        them from 'match_db' into 'couples'.

        RETURNS: True, if 'ia' are either in match_db or couples.
                 False, some 'ia' dropped out completely

        The found 'ib'-s occur only once in 'match_db' and are removed from
        there. No further treatment necessary.
        """
        ok_f = True
        ib_count = defaultdict(int)
        proposed = {}
        for ia, mate_list in match_db.items():
            for ib, analogy_list in mate_list:
                if ib_count[ib] == 0: proposed[ib] = (ia, analogy_list)
                ib_count[ib] += 1

        nominals_ultimate = [ib for ib, count in ib_count.items() if count == 1]
        for ib in nominals_ultimate:
            ia, analogy_list = proposed[ib]
            if ia in match_db:
                del match_db[ia] # The one and only occurence of 'ib' is removed here.
            if not analogy_db.update_if_consistent(analogy_list):
                ok_f = False
            else:
                couples[ia] = ib
        return ok_f

    def _remove_coupled_nominals(match_db, coupled_nominals):
        """Remove newly found 'coupled_nominals' from mate_lists-s.

        RETURNS: True, if 'ia' are either in match_db or couples.
                 False, some 'ia' dropped out completely
        """
        ok_f = True
        for ia, mate_list in list(match_db.items()):
            if not any(ib in coupled_nominals for ib, _ in mate_list):
                continue
            # remove entries from 'mate_list' which contain 'coupled_nominals'.
            new_mate_list = [
                (ib, analogy_list)
                for ib, analogy_list in mate_list if ib not in coupled_nominals
            ]
            if not new_mate_list:
                if ia in match_db:
                    del match_db[ia]
                    ok_f = False
            else:
                match_db[ia] = new_mate_list
        return ok_f

    couples          = {}
    analogy_db       = AnalogyDb()
    coupled_nominals = True
    while coupled_nominals:
        ok_f, coupled_nominals = _find_couples(match_db, couples)
        if abort_f and not ok_f: return None, None, None
        ok_f = _remove_coupled_nominals(match_db, coupled_nominals)
        if abort_f and not ok_f: return None, None, None
        _find_couples_inverse(match_db, couples, analogy_db)

    return match_db, couples, analogy_db

