"""
SPDX-Linces: MIT; (C) 2021 Frank-Rene Schaefer
"""
from   hwut.engine.compare.analogy_db import AnalogyDb

from   itertools   import zip_longest
from   collections import defaultdict

class LineDb:
    """Map: line index --> (line as string, line as 'Match' sequence)
    """
    def __init__(self, line_list, tolerance_table):
        """Maintains plain strings of lines and 'match_list'. The
        match list is only generated on demand.
        """

        # 'analyze_generator()' returns a generator.
        # It does nothing until it is applied.
        self.line_db         = dict((line_i, line) for line_i, line in enumerate(line_list))
        self.match_list_db   = {}
        self.tolerance_table = tolerance_table

    def __len__(self):
        return len(self.line_db)

    def __iter__(self):
        yield from self.line_db

    def get_match_list(self, line_i):
        """RETURNS: match list for line of index 'line_i'.

        Generators must now be replaced with lists. Otherwise, they
        cannot be referred more than once.
        """
        match_list = self.match_list_db.get(line_i)
        if match_list is None:
            match_list = list(self.tolerance_table.raw_match_list(self.line_db[line_i]))
            self.match_list_db[line_i] = match_list
        return match_list

    def line_items(self):
        """YIELDS: (line index, line) of all lines in the database.
        """
        yield from self.line_db.items()

    def match_list_items(self):
        """YIELDS: (line index, match list)

        for all items in 'self'. Generators which are not yet converted
        to lists are converted (but not entered).
        """
        for line_i in self.line_db.keys():
            match_list = self.get_match_list(line_i)
            yield line_i, match_list


class FriendsPairing:
    def __init__(self, tolerance_table, subject_line_list, nominal_line_list):
        self.tolerance_table = tolerance_table
        self.subject_db  = LineDb(subject_line_list, tolerance_table) # line index -> line, match_list
        self.nominal_db  = LineDb(nominal_line_list, tolerance_table) # line index -> line, match_list

        self.nominal_lines_with_analogy = set(
             ib
             for ib, nominal_line in self.nominal_db.line_db.items()
             if self.tolerance_table.has_analogy(nominal_line)
        )

    def do(self):
        """RETURNS: [0] verdict
                    [1] map: 'ia' --> 'ib'
                    [2] analogy_db

        Where 'ia' is the index of a line in 'subject_lines' that is equivalent
        and, thus, associated with 'ib' which is a line from 'nominal_lines'.
        """
        match_db           = self.__get_match_db()
        match_db, couples  = self._extract_ultimate_mates(match_db)

        return self._core(match_db, couples)

    def _core(self, match_db, couples):
        """L:         size of 'couples' if solution is complete.
           match_db:  map: 'ia' --> ('ib', required list of analogies)
           couples:   map: 'ia' --> 'ib'

        That is, 'couples' captured already the individuals for which there is
        no alternative than each other.

        RETURNS: [0] verdict
                 [1] map: 'ia' --> 'ib'
                 [2] analogy_db
        """
        L = max(len(self.subject_db), len(self.nominal_db))
        if not match_db:
            return len(couples) == L, couples, AnalogyDb()

        subject_singles_all = set(match_db.keys())

        class Item:
            def __init__(self, couples, analogy_db):
                self.couples    = couples
                self.analogy_db = analogy_db

            def new(self, ia, ib, analogy_list):
                # 'analogy_db' does not change elsewhere.
                # => Thus, isolate only on change, here.
                if analogy_list:
                    analogy_db = item.analogy_db.clone_update(analogy_list)
                else:
                    analogy_db = self.analogy_db
                couples     = dict(item.couples)  # isolate 'couple' database
                couples[ia] = ib
                return Item(couples, analogy_db)

        work_list = [
            (ia, Item(couples, AnalogyDb())) for ia in match_db.keys()
        ]
        best = Item({}, AnalogyDb())
        while work_list:
            ia, item = work_list.pop()

            nominals_taken = set(item.couples.values())
            nominal_singles = [
                (ib, analogy_list)
                for ib, analogy_list in match_db[ia]
                if ib not in nominals_taken
                if item.analogy_db.is_consistent(analogy_list)
            ]
            new_subject_singles = subject_singles_all.difference(item.couples.keys())
            new_subject_singles.remove(ia)
            for ib, analogy_list in nominal_singles:
                new_item = item.new(ia, ib, analogy_list)

                if len(item.couples) == L:
                    return True, new_item.couples, new_item.analogy_db

                if len(new_item.couples) > len(best.couples):
                    best = new_item

                work_list.extend((new_ia, new_item) for new_ia in new_subject_singles)

        return False, best.couples, best.analogy_db

    def _matches(self, ia, subject_line):
        """YIELDS: [0] 'ib' from 'nominal_available' where
                       subject_line_list[ia] matchs nominal_line_list[ib]
                   [1] list of analogies required for the equivalence to hold.
        """
        for ib, nominal_line in self.nominal_db.line_items():
            # If no analogies are involved, a plain match is sufficient
            if ib not in self.nominal_lines_with_analogy:
                if subject_line == nominal_line:
                    yield ib, []
                    continue

            subject_match_list = self.subject_db.get_match_list(ia)
            nominal_match_list = self.nominal_db.get_match_list(ib)
            verdict, \
            analogy_list = self.tolerance_table.judge(subject_match_list,
                                                      nominal_match_list)

            if verdict:
                yield ib, analogy_list

    def __get_match_db(self):
        match_db = dict()
        for ia, subject_line in self.subject_db.line_items():
            mate_list = list(self._matches(ia, subject_line))
            if not mate_list: continue
            match_db[ia] = mate_list
        return match_db

    def _extract_ultimate_mates(self, match_db):
        # Lines that only have one possible mate, can be taken directly
        def _ultimate_mate(mate_list):
            if not len(mate_list) == 1: return False
            ib, _ = mate_list[0]
            return ib not in self.nominal_lines_with_analogy

        couples = dict(
            (ia, mate_list[0][0])  # mate_list[0][0] = 'ib' of first entry in 'mate_list'
            for ia, mate_list in match_db.items() if _ultimate_mate(mate_list)
        )

        if couples:
            subjects_taken = couples.keys()
            nominals_taken = set(couples.values())
            for ia in subjects_taken:
                del match_db[ia]

            for ia, mate_list in list(match_db.items()):
                for i, entry in reversed(list(enumerate(mate_list))):
                    ib, _ = entry
                    if ib in nominals_taken: del mate_list[i]

        return match_db, couples

class FriendsPairingFailQuickly(FriendsPairing):
    def __init__(self, tolerance_table, subject_line_list, nominal_line_list):
        FriendsPairing.__init__(self, tolerance_table, subject_line_list, nominal_line_list)

    def do(self):
        """RETURNS: [0] verdict
                    [1] map: 'ia' --> 'ib'
                    [2] analogy_db

        Where 'ia' is the index of a line in 'subject_lines' that is equivalent
        and, thus, associated with 'ib' which is a line from 'nominal_lines'.
        """
        if len(self.subject_db) != len(self.nominal_db):
            return None

        match_db = self.__get_match_db()
        if match_db is None: return None, None

        match_db, couples = self._extract_ultimate_mates(match_db)

        return self._core(match_db, couples)

    def __get_match_db(self):
        match_db       = dict()
        nominals_found = set()
        for ia, subject_line in self.subject_db.line_items():
            mate_list = list(self._matches(ia, subject_line))
            if not mate_list: return None
            nominals_found.update(ib for ib, _ in mate_list)
            match_db[ia] = mate_list

        if len(nominals_found) != len(self.nominal_db): return None
        else:                                           return match_db
